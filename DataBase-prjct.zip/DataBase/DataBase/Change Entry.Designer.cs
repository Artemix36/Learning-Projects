﻿namespace DataBase
{
    partial class Change_Entry
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.FindName = new System.Windows.Forms.TextBox();
            this.Found = new System.Windows.Forms.DataGridView();
            this.find = new System.Windows.Forms.Button();
            this.ChangeName = new System.Windows.Forms.TextBox();
            this.change = new System.Windows.Forms.Button();
            this.ChangeArtist = new System.Windows.Forms.TextBox();
            this.ChangeLeft = new System.Windows.Forms.TextBox();
            this.FindArtist = new System.Windows.Forms.TextBox();
            this.Back = new System.Windows.Forms.Button();
            this.ChangeID = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.ChangePrice = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.Found)).BeginInit();
            this.SuspendLayout();
            // 
            // FindName
            // 
            this.FindName.Location = new System.Drawing.Point(13, 13);
            this.FindName.Multiline = true;
            this.FindName.Name = "FindName";
            this.FindName.Size = new System.Drawing.Size(398, 47);
            this.FindName.TabIndex = 0;
            // 
            // Found
            // 
            this.Found.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.Found.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Found.Location = new System.Drawing.Point(12, 119);
            this.Found.Name = "Found";
            this.Found.RowHeadersWidth = 72;
            this.Found.RowTemplate.Height = 31;
            this.Found.Size = new System.Drawing.Size(545, 201);
            this.Found.TabIndex = 1;
            // 
            // find
            // 
            this.find.Font = new System.Drawing.Font("Montserrat", 8.142858F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.find.Location = new System.Drawing.Point(613, 21);
            this.find.Name = "find";
            this.find.Size = new System.Drawing.Size(133, 38);
            this.find.TabIndex = 2;
            this.find.Text = "Поиск";
            this.find.UseVisualStyleBackColor = true;
            this.find.Click += new System.EventHandler(this.find_Click);
            // 
            // ChangeName
            // 
            this.ChangeName.Location = new System.Drawing.Point(13, 326);
            this.ChangeName.Multiline = true;
            this.ChangeName.Name = "ChangeName";
            this.ChangeName.Size = new System.Drawing.Size(398, 47);
            this.ChangeName.TabIndex = 4;
            // 
            // change
            // 
            this.change.Font = new System.Drawing.Font("Montserrat", 8.142858F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.change.Location = new System.Drawing.Point(623, 335);
            this.change.Name = "change";
            this.change.Size = new System.Drawing.Size(133, 38);
            this.change.TabIndex = 5;
            this.change.Text = "Изменить";
            this.change.UseVisualStyleBackColor = true;
            this.change.Click += new System.EventHandler(this.change_Click);
            // 
            // ChangeArtist
            // 
            this.ChangeArtist.Location = new System.Drawing.Point(13, 379);
            this.ChangeArtist.Multiline = true;
            this.ChangeArtist.Name = "ChangeArtist";
            this.ChangeArtist.Size = new System.Drawing.Size(398, 47);
            this.ChangeArtist.TabIndex = 6;
            // 
            // ChangeLeft
            // 
            this.ChangeLeft.Location = new System.Drawing.Point(13, 475);
            this.ChangeLeft.Multiline = true;
            this.ChangeLeft.Name = "ChangeLeft";
            this.ChangeLeft.Size = new System.Drawing.Size(40, 47);
            this.ChangeLeft.TabIndex = 8;
            // 
            // FindArtist
            // 
            this.FindArtist.Location = new System.Drawing.Point(12, 66);
            this.FindArtist.Multiline = true;
            this.FindArtist.Name = "FindArtist";
            this.FindArtist.Size = new System.Drawing.Size(398, 47);
            this.FindArtist.TabIndex = 9;
            // 
            // Back
            // 
            this.Back.Font = new System.Drawing.Font("Montserrat", 8.142858F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Back.Location = new System.Drawing.Point(466, 486);
            this.Back.Name = "Back";
            this.Back.Size = new System.Drawing.Size(322, 38);
            this.Back.TabIndex = 10;
            this.Back.Text = "Вернуться в главное меню";
            this.Back.UseVisualStyleBackColor = true;
            this.Back.Click += new System.EventHandler(this.Back_Click);
            // 
            // ChangeID
            // 
            this.ChangeID.Location = new System.Drawing.Point(769, 184);
            this.ChangeID.Multiline = true;
            this.ChangeID.Name = "ChangeID";
            this.ChangeID.Size = new System.Drawing.Size(56, 47);
            this.ChangeID.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(563, 234);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(266, 25);
            this.label1.TabIndex = 12;
            this.label1.Text = "ID изменяемого элемента";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(418, 348);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(199, 25);
            this.label2.TabIndex = 13;
            this.label2.Text = "Изменить название";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(417, 401);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(190, 25);
            this.label3.TabIndex = 14;
            this.label3.Text = "Изменить артиста";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(59, 488);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(190, 25);
            this.label4.TabIndex = 15;
            this.label4.Text = "Изменить остаток";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(417, 21);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(190, 25);
            this.label5.TabIndex = 16;
            this.label5.Text = "Найти по названию";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(417, 79);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(176, 25);
            this.label6.TabIndex = 17;
            this.label6.Text = "Найти по артисту";
            // 
            // ChangePrice
            // 
            this.ChangePrice.Location = new System.Drawing.Point(13, 432);
            this.ChangePrice.Multiline = true;
            this.ChangePrice.Name = "ChangePrice";
            this.ChangePrice.Size = new System.Drawing.Size(398, 47);
            this.ChangePrice.TabIndex = 18;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(418, 454);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(157, 25);
            this.label7.TabIndex = 19;
            this.label7.Text = "Изменить цену";
            // 
            // Change_Entry
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(837, 536);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.ChangePrice);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ChangeID);
            this.Controls.Add(this.Back);
            this.Controls.Add(this.FindArtist);
            this.Controls.Add(this.ChangeLeft);
            this.Controls.Add(this.ChangeArtist);
            this.Controls.Add(this.change);
            this.Controls.Add(this.ChangeName);
            this.Controls.Add(this.find);
            this.Controls.Add(this.Found);
            this.Controls.Add(this.FindName);
            this.Name = "Change_Entry";
            this.Text = "Change_Entry";
            ((System.ComponentModel.ISupportInitialize)(this.Found)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox FindName;
        private System.Windows.Forms.DataGridView Found;
        private System.Windows.Forms.Button find;
        private System.Windows.Forms.TextBox ChangeName;
        private System.Windows.Forms.Button change;
        private System.Windows.Forms.TextBox ChangeArtist;
        private System.Windows.Forms.TextBox ChangeLeft;
        private System.Windows.Forms.TextBox FindArtist;
        private System.Windows.Forms.Button Back;
        private System.Windows.Forms.TextBox ChangeID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox ChangePrice;
        private System.Windows.Forms.Label label7;
    }
}