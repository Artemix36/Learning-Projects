﻿namespace DataBase
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.button2 = new System.Windows.Forms.Button();
            this.NamingFiled = new System.Windows.Forms.TextBox();
            this.LeftField = new System.Windows.Forms.TextBox();
            this.ArtistFiled = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.Left_now = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Change_enter = new System.Windows.Forms.Button();
            this.EnterPrice = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.Left_now)).BeginInit();
            this.SuspendLayout();
            // 
            // button2
            // 
            this.button2.AutoSize = true;
            this.button2.Font = new System.Drawing.Font("Montserrat", 8.142858F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button2.Location = new System.Drawing.Point(729, 570);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(307, 42);
            this.button2.TabIndex = 1;
            this.button2.Text = "Добавить запись";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // NamingFiled
            // 
            this.NamingFiled.Font = new System.Drawing.Font("Montserrat", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.NamingFiled.Location = new System.Drawing.Point(12, 570);
            this.NamingFiled.Margin = new System.Windows.Forms.Padding(2);
            this.NamingFiled.Multiline = true;
            this.NamingFiled.Name = "NamingFiled";
            this.NamingFiled.Size = new System.Drawing.Size(377, 36);
            this.NamingFiled.TabIndex = 4;
            // 
            // LeftField
            // 
            this.LeftField.Font = new System.Drawing.Font("Montserrat", 8.142858F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LeftField.Location = new System.Drawing.Point(11, 689);
            this.LeftField.Margin = new System.Windows.Forms.Padding(2);
            this.LeftField.Multiline = true;
            this.LeftField.Name = "LeftField";
            this.LeftField.Size = new System.Drawing.Size(48, 36);
            this.LeftField.TabIndex = 5;
            // 
            // ArtistFiled
            // 
            this.ArtistFiled.Font = new System.Drawing.Font("Montserrat", 8.142858F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ArtistFiled.Location = new System.Drawing.Point(13, 612);
            this.ArtistFiled.Margin = new System.Windows.Forms.Padding(2);
            this.ArtistFiled.Multiline = true;
            this.ArtistFiled.Name = "ArtistFiled";
            this.ArtistFiled.Size = new System.Drawing.Size(377, 36);
            this.ArtistFiled.TabIndex = 6;
            // 
            // button1
            // 
            this.button1.AutoSize = true;
            this.button1.Font = new System.Drawing.Font("Montserrat", 8.142858F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.Location = new System.Drawing.Point(729, 618);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(307, 42);
            this.button1.TabIndex = 7;
            this.button1.Text = "Показать \"Наличие\"";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // button3
            // 
            this.button3.AutoSize = true;
            this.button3.Font = new System.Drawing.Font("Montserrat", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button3.Location = new System.Drawing.Point(729, 664);
            this.button3.Margin = new System.Windows.Forms.Padding(2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(307, 42);
            this.button3.TabIndex = 9;
            this.button3.Text = "Показать \"Нет в наличии\"";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // Left_now
            // 
            this.Left_now.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.Left_now.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Left_now.Location = new System.Drawing.Point(13, 12);
            this.Left_now.Margin = new System.Windows.Forms.Padding(4);
            this.Left_now.Name = "Left_now";
            this.Left_now.RowHeadersWidth = 10;
            this.Left_now.RowTemplate.Height = 31;
            this.Left_now.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.Left_now.Size = new System.Drawing.Size(1023, 539);
            this.Left_now.TabIndex = 8;
            this.Left_now.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(396, 580);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(284, 25);
            this.label1.TabIndex = 10;
            this.label1.Text = "Введите название пластинки";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(396, 618);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(307, 25);
            this.label2.TabIndex = 11;
            this.label2.Text = "Введите имя автора пластинки";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(66, 693);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(172, 25);
            this.label3.TabIndex = 12;
            this.label3.Text = "Введите остаток";
            // 
            // Change_enter
            // 
            this.Change_enter.AutoSize = true;
            this.Change_enter.Font = new System.Drawing.Font("Montserrat", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Change_enter.Location = new System.Drawing.Point(729, 710);
            this.Change_enter.Margin = new System.Windows.Forms.Padding(2);
            this.Change_enter.Name = "Change_enter";
            this.Change_enter.Size = new System.Drawing.Size(307, 42);
            this.Change_enter.TabIndex = 13;
            this.Change_enter.Text = "Изменить запись";
            this.Change_enter.UseVisualStyleBackColor = true;
            this.Change_enter.Click += new System.EventHandler(this.Change_enter_Click);
            // 
            // EnterPrice
            // 
            this.EnterPrice.Font = new System.Drawing.Font("Montserrat", 8.142858F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.EnterPrice.Location = new System.Drawing.Point(13, 652);
            this.EnterPrice.Margin = new System.Windows.Forms.Padding(2);
            this.EnterPrice.Multiline = true;
            this.EnterPrice.Name = "EnterPrice";
            this.EnterPrice.Size = new System.Drawing.Size(377, 36);
            this.EnterPrice.TabIndex = 14;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(396, 663);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(139, 25);
            this.label4.TabIndex = 15;
            this.label4.Text = "Введите цену";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1050, 776);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.EnterPrice);
            this.Controls.Add(this.Change_enter);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.Left_now);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.ArtistFiled);
            this.Controls.Add(this.LeftField);
            this.Controls.Add(this.NamingFiled);
            this.Controls.Add(this.button2);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_load);
            ((System.ComponentModel.ISupportInitialize)(this.Left_now)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox NamingFiled;
        private System.Windows.Forms.TextBox LeftField;
        private System.Windows.Forms.TextBox ArtistFiled;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.DataGridView Left_now;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button Change_enter;
        private System.Windows.Forms.TextBox EnterPrice;
        private System.Windows.Forms.Label label4;
    }
}

