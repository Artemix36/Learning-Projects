﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace DataBase
{
    internal class DB
    {
        MySqlConnection connect = new MySqlConnection("server = localhost; port = 3306; username = root; password = root; database = stock_of_vinyl");

        public void OpenConnect()
        {
            if(connect.State == System.Data.ConnectionState.Closed)
            {
                connect.Open ();
            }
            else
            {
                MessageBox.Show("Already opened");
            }
        }
        public void CloseConnect()
        {
            if (connect.State == System.Data.ConnectionState.Open)
            {
                connect.Close();
            }
            else
            {
                MessageBox.Show("Already closed");
            }
        }

        public MySqlConnection GetConnection()
        {
            return connect;
        }

    }
}
