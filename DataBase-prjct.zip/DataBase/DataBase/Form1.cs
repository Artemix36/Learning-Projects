﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace DataBase
{
    public partial class Form1 : Form
    {
        private Rectangle btn2OGrectangle;
        private Rectangle btn1OGrectangle;
        private Rectangle btn3OGrectangle;
        private Rectangle ogFormSize;
        private Rectangle Left_now_rectangle;
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e) //новая запись
        {
            if (isItem_exist())
            {
                return;
            }
            DB db = new DB();
            MySqlCommand cmd = new MySqlCommand("INSERT INTO `vinyl_in_stock` (`Naming`, `Artist`, `left`, Price) VALUES(@n, @a, @left, @price)", db.GetConnection());

            if (NamingFiled.Text.Length > 0)
            {
                cmd.Parameters.Add("@n", MySqlDbType.VarChar).Value = NamingFiled.Text;
            }
            else
            {
                MessageBox.Show("Не заполнено название пластинки");
                return;
            }

            if (ArtistFiled.Text.Length > 0)
            {
                cmd.Parameters.Add("@a", MySqlDbType.VarChar).Value = ArtistFiled.Text;
            }
            else
            {
                MessageBox.Show("Не заполнено имя артиста");
                return;
            }

            if (StringIsDigits(LeftField.Text) == true && LeftField.Text.Length>0)
            {
                int left = Convert.ToInt32(LeftField.Text);
                cmd.Parameters.Add("@left", MySqlDbType.Int32).Value = left;
            }
            else
            {
                MessageBox.Show("Неправильно заполнено поле количества");
                return;
            }

            if (StringIsDigits(EnterPrice.Text) == true && EnterPrice.Text.Length > 0)
            {
                int left = Convert.ToInt32(EnterPrice.Text);
                cmd.Parameters.Add("@price", MySqlDbType.Int32).Value = left;
            }
            else
            {
                MessageBox.Show("Неправильно заполнено поле цены");
                return;
            }

            db.OpenConnect();

            if (cmd.ExecuteNonQuery() == 1)
            {
                MessageBox.Show("Успешно добавлено");
            }
            else
            {
                MessageBox.Show("Возникла ошибка");
            }

            db.CloseConnect();

            NamingFiled.Text = null;
            ArtistFiled.Text = null;
            LeftField.Text = null;
            EnterPrice.Text = null; 

            button1_Click_1(sender, e);

        }

        public Boolean isItem_exist()
        {
            DB db = new DB();
            DataTable dt = new DataTable();
            MySqlDataAdapter adapter = new MySqlDataAdapter();
            MySqlCommand cmd = new MySqlCommand("SELECT * FROM `vinyl_in_stock` WHERE `Naming` = @N OR 'Artist' = @A", db.GetConnection());

            cmd.Parameters.Add("@N", MySqlDbType.VarChar).Value = NamingFiled.Text;
            cmd.Parameters.Add("@A", MySqlDbType.VarChar).Value = ArtistFiled.Text;

            adapter.SelectCommand = cmd;
            adapter.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                MessageBox.Show("Такая запись уже есть, введите другую");
                return true;
            }
            else
            {
                return false;
            }   
        }

        public bool StringIsDigits(string s)
        {
            foreach (var item in s)
            {
                if (!char.IsDigit(item))
                {
                    return false;
                }
            }
            return true;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            DB db = new DB();
            DataTable dt = new DataTable();
            MySqlDataAdapter adapter = new MySqlDataAdapter();
            MySqlCommand cmd = new MySqlCommand("SELECT `Naming`, `Artist`, `left`, Price FROM `vinyl_in_stock` WHERE `left` > 0", db.GetConnection());

            adapter.SelectCommand = cmd;
            adapter.Fill(dt);

            Left_now.DataSource = dt;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DB db = new DB();
            DataTable dt = new DataTable();
            MySqlDataAdapter adapter = new MySqlDataAdapter();
            MySqlCommand cmd = new MySqlCommand("SELECT `Naming`, `Artist`, `left`, Price FROM `vinyl_in_stock` WHERE `left` = 0", db.GetConnection());

            adapter.SelectCommand = cmd;
            adapter.Fill(dt);

            Left_now.DataSource = dt;
        }

        private void Form1_load(object sender, EventArgs e)
        {
            ogFormSize = new Rectangle(this.Location.X, this.Location.Y, this.Width, this.Height);
            btn1OGrectangle = new Rectangle(button1.Location.X, button1.Location.Y, button1.Width, button1.Height);
            btn2OGrectangle = new Rectangle(button2.Location.X, button2.Location.Y, button2.Width, button2.Height);
            btn3OGrectangle = new Rectangle(button3.Location.X, button3.Location.Y, button3.Width, button3.Height);
            Left_now_rectangle = new Rectangle(Left_now.Location.X, Left_now.Location.Y, Left_now.Width,Left_now.Height); 
            button1_Click_1(sender, e);
            
        }

        private void resizeCTRL(Rectangle r, Control c)
        {
            float xRatio = (float)(this.Width) / (float)(ogFormSize.Width);
            float yRatio = (float)(this.Height) / (float)(ogFormSize.Height);

            int newX = (int)(r.Width * xRatio);
            int newY = (int)(r.Height * yRatio);

            int newWidth = (int)(r.Width * xRatio);
            int newHeight = (int)(r.Height * yRatio);

            c.Location = new Point(newX, newY);
            c.Size = new Size(newWidth, newHeight);
        }

        private void Form1_resize(object sender, EventArgs e)
        {
            resizeCTRL(btn1OGrectangle, button1);
            resizeCTRL(btn2OGrectangle, button2);
            resizeCTRL(btn3OGrectangle, button3);
            resizeCTRL(Left_now_rectangle, Left_now);
        }

        private void Change_enter_Click(object sender, EventArgs e)
        {
            Change_Entry frm2 = new Change_Entry();
            frm2.Show();
        }
    }



}
