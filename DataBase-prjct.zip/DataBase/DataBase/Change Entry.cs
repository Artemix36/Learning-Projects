﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataBase
{
    public partial class Change_Entry : Form
    {
        public int id;
        public Change_Entry()
        {
            InitializeComponent();
        }

        private void find_Click(object sender, EventArgs e)
        {
            DB db = new DB();
            DataTable dt = new DataTable();
            MySqlDataAdapter adapter = new MySqlDataAdapter();
            MySqlCommand cmd = new MySqlCommand("SELECT `id`, `Naming`, `Artist`, Price, `left` FROM `vinyl_in_stock` WHERE `Naming` = @n OR `Artist` = @A ", db.GetConnection());

            if (FindName.Text.Length == 0 && FindArtist.Text.Length == 0)
            {
                MessageBox.Show("Ничего не заполнено! Поиск не выполнить");
                return;
            }
            else
            {
                cmd.Parameters.Add("@n", MySqlDbType.VarChar).Value = FindName.Text;
                cmd.Parameters.Add("@A", MySqlDbType.VarChar).Value = FindArtist.Text;
                MySqlCommand id_finder = new MySqlCommand("SELECT `id` FROM `vinyl_in_stock` WHERE `Naming` = @n OR `Artist` = @A ", db.GetConnection());
                id_finder.Parameters.Add("@n", MySqlDbType.VarChar).Value = FindName.Text;
                id_finder.Parameters.Add("@A", MySqlDbType.VarChar).Value = FindArtist.Text;
                db.OpenConnect();
                string id = id_finder.ExecuteScalar().ToString();
                ChangeID.Text = id;
                db.CloseConnect();
            }

            adapter.SelectCommand = cmd;
            adapter.Fill(dt);

            Found.DataSource = dt;

            MySqlCommand name_finder = new MySqlCommand("SELECT `Naming` FROM `vinyl_in_stock` WHERE `Naming` = @n OR `Artist` = @A ", db.GetConnection());
            name_finder.Parameters.Add("@n", MySqlDbType.VarChar).Value = FindName.Text;
            name_finder.Parameters.Add("@A", MySqlDbType.VarChar).Value = FindArtist.Text;
            MySqlCommand artist_finder = new MySqlCommand("SELECT `Artist` FROM `vinyl_in_stock` WHERE `Naming` = @n OR `Artist` = @A ", db.GetConnection());
            artist_finder.Parameters.Add("@n", MySqlDbType.VarChar).Value = FindName.Text;
            artist_finder.Parameters.Add("@A", MySqlDbType.VarChar).Value = FindArtist.Text;
            MySqlCommand price_finder = new MySqlCommand("SELECT `Price` FROM `vinyl_in_stock` WHERE `Naming` = @n OR `Artist` = @A ", db.GetConnection());
            price_finder.Parameters.Add("@n", MySqlDbType.VarChar).Value = FindName.Text;
            price_finder.Parameters.Add("@A", MySqlDbType.VarChar).Value = FindArtist.Text;

            db.OpenConnect();
            string Name_found = name_finder.ExecuteScalar().ToString();
            string Artist_found = artist_finder.ExecuteScalar().ToString();
            string price_found = price_finder.ExecuteScalar().ToString();
            ChangeName.Text = Name_found;
            ChangeArtist.Text = Artist_found;
            ChangePrice.Text = price_found;
            db.CloseConnect();
        }

        private void Back_Click(object sender, EventArgs e)
        {
            Form1 frm2 = new Form1();
            this.Hide();
        }
        public bool StringIsDigits(string s)
        {
            foreach (var item in s)
            {
                if (!char.IsDigit(item))
                {
                    return false;
                }
            }
            return true;
        }

        private void change_Click(object sender, EventArgs e)
        {
            DB db = new DB();
            DataTable dt = new DataTable();
            MySqlDataAdapter adapter = new MySqlDataAdapter();
            MySqlCommand cmd = new MySqlCommand("SELECT `id`, `Naming`, `Artist`, `left`, Price FROM `vinyl_in_stock` WHERE `Naming` = @n OR `Artist` = @A ", db.GetConnection());
            cmd.Parameters.Add("@n", MySqlDbType.VarChar).Value = FindName.Text;
            cmd.Parameters.Add("@A", MySqlDbType.VarChar).Value = FindArtist.Text;

            if (ChangeID.Text.Length > 0)
            {

                if (ChangeName.Text.Length > 0)
                {
                    MySqlCommand cmd1 = new MySqlCommand("UPDATE vinyl_in_stock SET `Naming` = @N WHERE `id` = @i", db.GetConnection());
                    cmd1.Parameters.Add("@N", MySqlDbType.VarChar).Value = ChangeName.Text;
                    cmd1.Parameters.Add("@i", MySqlDbType.VarChar).Value = ChangeID.Text;
                    db.OpenConnect();
                    if (cmd1.ExecuteNonQuery() == 1)
                    {
                        MessageBox.Show("Успешно добавлено");
                    }
                    else
                    {
                        MessageBox.Show("Возникла ошибка");
                    }
                    db.CloseConnect();
                }
                if (ChangeArtist.Text.Length > 0)
                {
                    MySqlCommand cmd2 = new MySqlCommand("UPDATE vinyl_in_stock SET `Artist` = @A WHERE `id` = @i", db.GetConnection());
                    cmd2.Parameters.Add("@A", MySqlDbType.VarChar).Value = ChangeArtist.Text;
                    cmd2.Parameters.Add("@i", MySqlDbType.VarChar).Value = ChangeID.Text;
                    db.OpenConnect();
                    if (cmd2.ExecuteNonQuery() == 1)
                    {
                    }
                    else
                    {
                        MessageBox.Show("Возникла ошибка");
                    }
                    db.CloseConnect();
                }

                if (StringIsDigits(ChangeLeft.Text) == true && ChangeLeft.Text.Length > 0)
                {
                    int left = Convert.ToInt32(ChangeLeft.Text);
                    MySqlCommand cmd3 = new MySqlCommand("UPDATE vinyl_in_stock SET `left` = @left WHERE `id` = @i", db.GetConnection());
                    cmd3.Parameters.Add("@left", MySqlDbType.Int32).Value = left;
                    cmd3.Parameters.Add("@i", MySqlDbType.VarChar).Value = ChangeID.Text;
                    db.OpenConnect();
                    if (cmd3.ExecuteNonQuery() == 1)
                    {
                    }
                    else
                    {
                        MessageBox.Show("Возникла ошибка");
                    }
                    db.CloseConnect();
                }

                if (StringIsDigits(ChangePrice.Text) == true && ChangePrice.Text.Length > 0)
                {
                    int left = Convert.ToInt32(ChangePrice.Text);
                    MySqlCommand cmd3 = new MySqlCommand("UPDATE vinyl_in_stock SET `price` = @price WHERE `id` = @i", db.GetConnection());
                    cmd3.Parameters.Add("@price", MySqlDbType.Int32).Value = left;
                    cmd3.Parameters.Add("@i", MySqlDbType.VarChar).Value = ChangeID.Text;
                    db.OpenConnect();
                    if (cmd3.ExecuteNonQuery() == 1)
                    {
                    }
                    else
                    {
                        MessageBox.Show("Возникла ошибка");
                    }
                    db.CloseConnect();
                }

                adapter.SelectCommand = cmd;
                adapter.Fill(dt);

                Found.DataSource = dt;

                FindName.Text = null;
                FindArtist.Text = null;
                ChangeArtist.Text = null;
                ChangeName.Text = null;
                ChangeLeft.Text = null;
            }
            else
            {
                MessageBox.Show("Введите ID элемента, который надо изменить");
                return;
            }
        }
    }
}
